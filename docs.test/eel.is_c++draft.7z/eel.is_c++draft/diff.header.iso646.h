<!DOCTYPE html><html lang='en'><head><title>[diff.header.iso646.h]</title><meta charset='UTF-8'/><link rel='stylesheet' type='text/css' href='14882.css'/><link rel='stylesheet' type='text/css' href='expanded.css' title='Normal'/><link rel='alternate stylesheet' type='text/css' href='colored.css' title='Notes and examples colored'/><link rel='alternate stylesheet' type='text/css' href='normative-only.css' title='Notes and examples hidden'/><link rel='icon' href='icon.png'/></head><body><div class='wrapper'><h1 ><a class='annexnum' style='min-width:50pt'>Annex C&emsp;(informative)</a> Compatibility <a class='abbr_ref' href='./#diff'>[diff]</a></h1><h2 ><a class='secnum' style='min-width:65pt'>C.7</a> C standard library <a class='abbr_ref' href='diff.library#diff.header.iso646.h'>[diff.library]</a></h2><h3 ><a class='secnum' style='min-width:80pt'>C.7.3</a> Modifications to definitions <a class='abbr_ref' href='diff.mods.to.definitions#diff.header.iso646.h'>[diff.mods.to.definitions]</a></h3><h4 ><a class='secnum' style='min-width:95pt'>C.7.3.4</a> Header <span class='texttt'>&lt;iso646.h&gt;</span> <a class='abbr_ref'>[diff.header.iso646.h]</a></h4><div class='para' id='1'><div class='marginalizedparent'><a class='marginalized' href='#1'>1</a></div><div class='sourceLinkParent'><a class='sourceLink' href='http://github.com/Eelis/draft/tree/4d5d40dd74d0062cbcd086381b8f51b606740cf6/source/compatibility.tex#L3078'>#</a></div><div class='texpara'><div id='1.sentence-1' class='sentence'>The tokens
<span id=':and'><span class='texttt'>and</span></span>,
<span id=':and_eq'><span class='texttt'>and_<span class='shy'></span>eq</span></span>,
<span id=':bitand'><span class='texttt'>bitand</span></span>,
<span id=':bitor'><span class='texttt'>bitor</span></span>,
<span id=':compl'><span class='texttt'>compl</span></span>,
<span id=':not'><span class='texttt'>not</span></span>,
<span id=':not_eq'><span class='texttt'>not_<span class='shy'></span>eq</span></span>,
<span id=':or'><span class='texttt'>or</span></span>,
<span id=':or_eq'><span class='texttt'>or_<span class='shy'></span>eq</span></span>,
<span id=':xor'><span class='texttt'>xor</span></span>,
and
<span id=':xor_eq'><span class='texttt'>xor_<span class='shy'></span>eq</span></span>
are keywords in C++ (<a href='lex.key' title='5.11&emsp;Keywords'>[lex.<span class='shy'></span>key]</a>),
and are not introduced as macros
by <a href='iso646.h.syn#header:%3ciso646.h%3e' title='17.14.3&emsp;Header &lt;iso646.h&gt; synopsis&emsp;[iso646.h.syn]'><span id='headerref:<iso646.h>'><span class='texttt'>&lt;iso646.h&gt;</span></span></a><a class='hidden_link' href='#1.sentence-1'>.</a></div></div></div></div></body></html>